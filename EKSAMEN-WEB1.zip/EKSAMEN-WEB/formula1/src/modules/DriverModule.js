/*
// skulle lage spørsmål men misforstod oppgaven at man skal hente fra webapi
const DriverModule = (()=>{
    const array = [
        {
            name: "Max Verstappen",
            manufacter: "Red Bull Racing",
            age: 23,
            natinality: "Dutch",
            image: "verstappen.webp"
        },
        {
            name: "Lewis Hamilton",
            manufacter: "Mercedes",
            age: 36,
            natinality: "British",
            image: "hamilton.webp"
        },
        {
            name: "Sergio Perez",
            manufacter: "Red Bull Racing",
            age: 31,
            natinality: "Mexican",
            image: "perez.webp"
        },
        {
            name: "Lando Norris",
            manufacter: "McLaren",
            age: 21,
            natinality: "British",
            image: "norris.webp"
        },
        {
            name: "Fernando Alonso",
            manufacter: "Aston Martin",
            age: 39,
            natinality: "Spanish",
            image: "alonso.webp"
        },
        {
            name: "Carlos Sainz",
            manufacter: "Ferrari",
            age: 26,
            natinality: "Spanish",
            image: "sainz.webp"
        }
    ];

    const getDrivers = () => array;

    return {
        getDrivers
    }
})()

export default DriverModule;
*/