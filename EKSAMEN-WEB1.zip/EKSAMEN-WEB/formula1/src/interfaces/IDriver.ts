// Representerer fra webapi og til react
export interface IDriver {
    id?: number;
    name: string;
    manufacturer: string;
    age: number;
    nationality: string;
    image: string;
}