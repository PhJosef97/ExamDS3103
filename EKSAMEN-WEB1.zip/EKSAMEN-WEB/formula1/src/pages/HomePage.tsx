

const HomePage = () => {
    return (
        <section>
            <h1 className="text-success display-4 mb-5">Home Page</h1>
            <article className="col">
                <p>
                Lorem ipsum dolor, sit amet consectetur adipisicing elit. 
                Nostrum maiores provident laudantium fuga magnam! 
                Distinctio omnis voluptate est inventore quam. 
                Voluptatem vero suscipit quis. Fugiat unde harum illo hic option.
                </p>
            </article>
        </section>
    )
}

export default HomePage;