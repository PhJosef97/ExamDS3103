const EndpointsDriverPage = () => {
    const endpointUrl = "http://localhost:5178/index.html";

    return (
        <a href={endpointUrl}>
            <h1 className="text-light">LINKEN TIL ENDEPUNKET</h1>
        </a>
    );
};

export default EndpointsDriverPage;
