/*namespace Formula1API.Interfaces;

    public interface IQuiz
    {
        string? Question { get; set; }
        string[]? Options { get; set; }
        string? CorrectAnswer { get; set; }
    }*/