/*namespace Formula1API.Models;
using Formula1API.Interfaces;
public class Quiz : IQuiz
{
    public string? Question { get; set; }
    public string[]? Options { get; set; }
    public string? CorrectAnswer { get; set; }
}*/