/*namespace DAPI.models;

using DAPI.models;


public class DriverDTO
{
    public int Id { get; set; }
    public string? Name { get; set; }
    public string? Manufacturer { get; set; }
    public int Age { get; set; }
    public string? Nationality { get; set; }
}
*/